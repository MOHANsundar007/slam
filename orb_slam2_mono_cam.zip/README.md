# ORB-SLAM2 with Monocular USB Camera

## 📦 Setup Instructions

### 1. Prerequisites
Install dependencies:
```bash
sudo apt install ros-noetic-usb-cam
```

Clone ORB_SLAM2 into your workspace:
```bash
cd ~/catkin_ws/src
git clone https://github.com/raulmur/ORB_SLAM2.git
cd ORB_SLAM2
chmod +x build.sh
./build.sh
```

Download the vocabulary file:
```bash
cd Vocabulary
wget https://github.com/raulmur/ORB_SLAM2/blob/master/Vocabulary/ORBvoc.txt.tar.gz?raw=true -O ORBvoc.txt.tar.gz
tar -xzvf ORBvoc.txt.tar.gz
```

### 2. Add This Package
Place this package in `~/catkin_ws/src`:
```bash
cd ~/catkin_ws/src
unzip orb_slam2_mono_cam.zip
```

### 3. Build and Source
```bash
cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

### 4. Run the Launch File
```bash
roslaunch orb_slam2_mono_cam orb_slam2.launch
```

Make sure your webcam is connected and available as `/dev/video0`.

---

Happy Mapping! 🌍🤖
